angular.module('indeApp.controllers').controller('InputCtrl', function ($scope, passService) {
  $scope.inputVar = passService.sharedVariable;
  $scope.usrMnu = [
      {
         "linkID":"link1",
         "linkTxt":"Manage IDZ Profile"
      },
      {
         "linkID":"link2",
         "linkTxt":"INDE Support"
      },
      {
         "linkID":"link3",
         "linkTxt":"Read FAQ"
      },
      {
         "linkID":"link4",
         "linkTxt":"Logout"
      }];
  $scope.filterMnu = [
      {
         "linkID":"android",
         "linkTxt":"Android"
      },
      {
         "linkID":"win",
         "linkTxt":"Windows"
      },
      {
         "linkID":"mac",
         "linkTxt":"Mac"
      },
      {
         "linkID":"installed",
         "linkTxt":"Installed Components"
      },
      {
         "linkID":"update",
         "linkTxt":"Updates"
      }];
});