angular.module('indeApp.controllers').controller('InputCtrl', function ($scope, passService) {
  $scope.inputVar = passService.sharedVariable;
});