angular.module('indeApp.controllers').controller('ComponentCtrl', function ($scope, $filter, $window, passService, socketService) {

$scope.getOff = function() {
         x = document.getElementById('test');
         return x.offsetWidth;
   }
   $scope.len = 0;

   $scope.init = function() {
      $scope.inputVar = passService.sharedVariable;
   	var compData = [
      {
         "compN":"Audio/Video",
         "compBG":"#797470",
         "status":"Download",
         "descr":"Audio/Video Lorem ipsum dolor sit amet, consectetur update elit. Praesentium, unde, rem in labore impedit veritatis sequi deleniti perferendis voluptatibus odio dolore natus mollitia et reiciendis voluptates aliquam molestiae enim itaque non consectetur aut consequuntur iusto voluptatum velit quia repellendus quasi ut quis porro fugiat molestias vero nemo repellat accusamus ullam excepturi omnis iste deserunt provident nesciunt eum expedita! Nemo, eligendi? ",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"},
            {"id":6,"document":"Testing for double rows and 6 documents high."},
            {"id":7,"document":"Testing for double rows and 6 documents high."}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            ]
      },
      {
         "compN":"Threading",
         "compBG":"#8D847B",
         "status":"Download",
         "descr":"Threading Lorem ipsum dolor sit amet, update adipisicing elit. Rerum eos officia aliquid iusto similique possimus laboriosam quidem reiciendis? Dignissimos, quo, nemo quia ipsam quam dolore architecto voluptatum quibusdam libero eius excepturi vitae voluptas eum recusandae maiores accusantium iusto molestiae aperiam ipsum dolorum quae tenetur laborum officiis quaerat nobis debitis magni eaque illo vel reiciendis! Nulla, optio, sint, enim, odit illo est adipisci doloremque dolorem delectus repellendus sunt unde numquam voluptate.",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Compiler",
         "compBG":"#A39A93",
         "status":"Installed",
         "descr":"Compiler Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, dolorum, assumenda, nobis asperiores adipisci vitae nam magni similique reprehenderit inventore rerum suscipit totam voluptate amet iusto non ab veniam! Neque, quae, debitis, corporis, voluptate labore ducimus ab totam adipisci minus laboriosam necessitatibus distinctio. Aliquid, nam, quod, veniam, quas modi sed sapiente earum beatae sit voluptas similique animi ipsa facilis temporibus eius impedit perferendis suscipit esse recusandae quam iusto repellat cupiditate labore. Alias natus iusto fugiat.",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"System Analyzer",
         "compBG":"#797470",
         "status":"Download",
         "descr":"System Analyzer Lorem ipsum dolor sit amet, consectetur.",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            ]
      },
      {
         "compN":"Platform Analyzer",
         "compBG":"#8D847B",
         "status":"Download",
         "descr":"Platform analyzer Lorem ipsum dolor sit amet, consectetur bus.",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Frame Analyzer",
         "compBG":"#A39A93",
         "status":"Download",
         "descr":"Description 6 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Frame Debugger (beta)",
         "compBG":"#797470",
         "status":"Installed",
         "descr":"Description 7 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Kernel Builder",
         "compBG":"#8D847B",
         "status":"Download",
         "descr":"Description 8 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Android Development Environment",
         "compBG":"#A39A93",
         "status":"Download",
         "descr":"Description 9 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Coming Soon",
         "compBG":"#797470",
         "status":"Installed",
         "descr":"Description 10 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Coming Soon",
         "compBG":"#8D847B",
         "status":"Download",
         "descr":"Description 1 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Coming Soon",
         "compBG":"#A39A93",
         "status":"Download",
         "descr":"Description 2 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      },
      {
         "compN":"Coming Soon",
         "compBG":"#797470",
         "status":"Download",
         "descr":"Description 3 lskjeflkjelsjfksejflejf lekfjselkef slekjf",
         "docu":[
            {"id":1,"document":"Product Brief(PDF)"},
            {"id":2,"document":"Release"},
            {"id":3,"document":"Installation Notes"},
            {"id":4,"document":"User Guide"},
            {"id":5,"document":"Optimization Guide"}
            ],
         "samp":[
            {"id":1,"type":"android","sample":"Sample file Lorem ipsum dolor. "},
            {"id":2,"type":"android","sample":"Lorem ipsum dolor sit. "},
            {"id":3,"type":"win","sample":"Lorem ipsum dolor sit amet."},
            {"id":4,"type":"win","sample":"Lorem ipsum dolor sit amet, consectetur."},
            {"id":5,"type":"mac","sample":"Lorem ipsum dolor."},
            {"id":6,"type":"mac","sample":"Lorem ipsum dolor sit amet, consectetur."}
            ]
      }
      ];

      $scope.selectedItem = -1;
      $scope.selectedRow = -1;
      $scope.$watch('inputVar.filt', function(val) {
         $scope.selectedItem = -1;
         $scope.selectedRow = -1;
         var addIndex = function(item, index) { 
            item.index = index;
         };
         var temp = $filter('filter')(compData, $scope.inputVar.filt);
         temp.forEach(addIndex);
         var rows = temp.chunk(4);
         rows.forEach(function(item, index) {
            item.index = index;
         })
         $scope.components = rows;
         $scope.len = $scope.components.length;
      });
      
      return $scope.components;
   };
   $scope.selected = undefined;
   $scope.selectIt = function(value) {
      $scope.selectedItem = value;
      $scope.selectedRow = Math.floor(value / 4);
   }
   $scope.toggleVisibility = function(component) {
      $scope.selected = component;
   };
   $scope.isVisible = function(component) {
      return $scope.selected === component;
   };

});