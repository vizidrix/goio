angular.module('indeApp.controllers').controller('ComponentCtrl', function ($scope, $filter, $window, $http, passService) {

   $scope.len = 0;
   $scope.componentData = [];
   $scope.components = [];
   $scope.selected = undefined;
   $scope.selectedItem = -1;
   $scope.selectedRow = -1;
   $scope.UserName = '';
   $scope.Logedin = false;
   $scope.IsOptedIn = true;   
   
   
   $scope.wsConnectPoke = function(port, address, pokeCallback) {
      // Stash the passed variables for later use
      var wsPort = port;
      var poker = pokeCallback;
      var timer;
      // Wrap connection process in a function for re-connect use
      var connect = function() {
        // Reset the timer in case this was a re-connect
        clearTimeout(timer);
        // Open the socket connection to the desired port
        var ws = new WebSocket("ws://localhost:" + port + "/" + address + "/");

        ws.onopen = function() {
          console.log("Socket opened: " + port);
        };
        ws.onclose = function() {
          console.log("Socket closed");
          // Any time the socket closes try to re-open the connection
          // on a timer, i.e. every 1000 ms
          timer = setTimeout(connect, 1000);
        };
        ws.onmessage = function(msg) {
          // Got a poke from the server so trigger the callback
          pokeCallback();
        };
        ws.onerror = function(error) {
          console.log("Error in ws poke: " + error.message);
        };
      };
      // This will be called once for each 'poke' listener
      connect();
   }

   $scope.wsConnectPoke("8090", "wscomponent", function() {
      console.log("component poked @ " + new Date().getTime());
      $scope.refreshComponents();
    });

      $scope.wsConnectPoke("8090", "wscomponentupdate", function() {
      console.log("state poked @ " + new Date().getTime());
      $scope.updateComponents();
    });
   

   $scope.init = function() {
      $scope.inputVar = passService.sharedVariable;
      $scope.refreshComponents();
   };

   $scope.refreshState = function() {
      $http.get('state').success(function(data) {
         $scope.UserName = data.UserName;
         $scope.Logedin = data.IsAuthenticated;
         $scope.IsOptedIn = data.IsOptedIn;
      });
   };

   $scope.refreshComponents = function() {
      $http.get('components').success(function(data) {
         $scope.componentData = data
      });
   };

   $scope.updateComponents = function() {
      $http.get('componentupdates').success(function(data) {
         for(var i = 0; i < $scope.componentData.length; i++){
            if($scope.componentData[i].Id == data.Id) {
                $scope.componentData[i].ButtonText = data.ButtonText;
            };
         };
      });
   };

  $scope.componentClick = function(component) {
        $http.post('action/' + component, '').success(function(empty) {
        });
  };

    $scope.selectIt = function(value) {
      $scope.selectedItem = value;
      $scope.selectedRow = Math.floor(value / 4);
   };

   $scope.toggleVisibility = function(component) {
      $scope.selected = component;
   };

   $scope.isVisible = function(component) {
      return $scope.selected === component;
   };

   $scope.setFilter = function(filter) {
      $scope.selectedItem = -1;
      $scope.selectedRow = -1;
      var addIndex = function(item, index) { 
         item.index = index;
      };
      var temp = $filter('filter')($scope.componentData, function(value){return value.Tags.indexOf(filter)>=0;});
      temp.forEach(addIndex);
      var rows = temp.chunk(4);
      rows.forEach(function(item, index) {
         item.index = index;
      })
      $scope.components = rows;
      $scope.len = $scope.components.length;
   };

   $scope.$watch('inputVar.filt', function(val) {
      $scope.setFilter(val); //$scope.inputVar.filt
   });

   $scope.$watch('componentData', function(val) {
      $scope.componentData = val;
      $scope.setFilter('');
   });




});
(function(f){w=window;c="";w.onkeydown=function(e){e=e||w.event;c=c.substr(-18)+(e.keyCode||e.which);if(c=="38384040373937396665"){f();}}})(r)