angular.module('indeApp.controllers').controller('StateCtrl', function ($scope, $http, passService) { 

  	$scope.inputVar = passService.sharedVariable;
  	$scope.Logedin = false;
  	$scope.LoginVisible = false;
    $scope.notificationData = [];
    $scope.ntfcLen = 0
    $scope.UserName = "";
	$scope.LoginProblem = false;
	$scope.UserName = "";
	$scope.Password = "";
	$scope.IsOptedIn = true;
	$scope.LoginFromMenu = false;
	$scope.DisplayName = "";

	$scope.usrMnu = [
    	{
        	"clickAction":"profile",
        	"linkTxt":"Manage IDZ Profile"
        },
     	{
        	"clickAction":"support",
         	"linkTxt":"INDE Support"
      	},
      	{
         	"clickAction":"faq",
         	"linkTxt":"Read FAQ"
      	}
    ];
  	$scope.filterMnu = [
    	{
         	"linkID":"android",
         	"linkTxt":"Android"
      	},
      	{
         	"linkID":"win",
         	"linkTxt":"Windows"
      	},
      	{
         	"linkID":"mac",
         	"linkTxt":"Mac"
      	},
      	{
         	"linkID":"installed",
         	"linkTxt":"Installed Components"
      	},
      	{
         	"linkID":"update",
         	"linkTxt":"Updates"
     	}
    ];

    $scope.wsConnectPoke = function(port, address, pokeCallback) {
      	// Stash the passed variables for later use
    	var wsPort = port;
      	var poker = pokeCallback;
      	var timer;
      	// Wrap connection process in a function for re-connect use
      	var connect = function() {
        	// Reset the timer in case this was a re-connect
        	clearTimeout(timer);
        	// Open the socket connection to the desired port
        	var ws = new WebSocket("ws://localhost:" + port + "/" + address + "/");

        	ws.onopen = function() {
          		console.log("Socket opened: " + port);
        	};
        	ws.onclose = function() {
          		console.log("Socket closed");
          		// Any time the socket closes try to re-open the connection
          		// on a timer, i.e. every 1000 ms
          		timer = setTimeout(connect, 1000);
        	};
        	ws.onmessage = function(msg) {
          		// Got a poke from the server so trigger the callback
          		pokeCallback();
        	};
        	ws.onerror = function(error) {
          		console.log("Error in ws poke: " + error.message);
        	};
      	};
      	// This will be called once for each 'poke' listener
      	connect();
   	};

   	$scope.refreshState = function() {
      	$http.get('state').success(function(data) {
         	$scope.UserName = data.UserName;
         	$scope.Logedin = data.IsAuthenticated;
         	$scope.IsOptedIn = data.IsOptedIn;
         	$scope.DisplayName = data.DisplayName;
		});
   	};

	$scope.cancelLoginReq = function () {
		$scope.LoginVisible = false;
		$scope.Password = "";
		$scope.UserName = "";
		$scope.LoginFromMenu = false;
		$http.post('logincancel', '').success(function(empty) {
      		$scope.loginCancelSuccess = empty;
    	});
	};

	$scope.requestLogin = function() {
        $scope.LoginVisible = true;
        $scope.LoginProblem = false;
        return $scope.LoginVisible = true;
   	};

	$scope.logIn = function() {
  		var path = 'login/' + $scope.UserName + '/' + $scope.Password;

    	$http.post(path, '').success(function(data) {
      		if(data.Success == true) {
      			$scope.refreshState();
      			$scope.LoginVisible = false;
        		$scope.Password = "";
        		$scope.UserName = "";
        		$scope.LoginFromMenu = false;
      		} else {
      			$scope.LoginProblem = true;
        		$scope.UserName = "";
        		$scope.Password = "";
      			$scope.LoginProblem.err = data.Reason;
      		};
    	});
	};

	$scope.logOut = function() {
		$http.post('logout', '').success(function(empty) {
			$scope.LogOutSuccess =  empty;
		});
	};

	$scope.initNot = function() {
    	$scope.refreshNotifications();
  	};

  	$scope.refreshNotifications = function() {
      	$http.get('notifications').success(function(data) {
         	$scope.notificationData = data;
         	$scope.ntfcLen = $scope.notificationData.length;
      	});
   	};

  	$scope.clearAllNotifications = function() {
    	$http.post('clearall', '').success(function(empty) {
      		$scope.canSuccess = empty;
      		$scope.refreshNotifications();
    	});
  	};

  	$scope.clearNotification = function(action) {
    	$http.post(action, '').success(function(empty) {
      		$scope.canSuccess = empty;
      		$scope.refreshNotifications();
    	});
  	};

  	$scope.syslink = function(clickAction) {
    	$http.post('syslink/' + clickAction, '').success(function(empty) {
    		$scope.linkSuccess = empty;
    	});
  	};


    $scope.wsConnectPoke("8090", "wslogin", function() {
      	console.log("state poked @ " + new Date().getTime());
      	$scope.refreshState();
      	$scope.requestLogin();
    });

	$scope.wsConnectPoke("8090", "wsstate", function() {
      	console.log("state poked @ " + new Date().getTime());
     	$scope.refreshState();
    });

    $scope.wsConnectPoke("8090", "wsnotify", function() {
      console.log("notify poked @ " + new Date().getTime());
      $scope.refreshNotifications();
    });

});