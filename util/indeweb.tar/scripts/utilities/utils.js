Array.prototype.chunk = function(chunksize) {
   var array = this;
   return [].concat.apply([],
      array.map(function(elem, i) {
         return i%chunksize ? [] : [array.slice(i, i+chunksize)];
      }))
};
var r=function(){alert('contra');};