angular.module('indeApp.factories').factory('socketService' function () {

   var ws = new WebSocket("ws://localhost:8090/ws/");
   var wsPoke = false;

   ws.onopen = function() {  
        console.log("Socket has been opened!");  
    };

    ws.onclose = function() {
      console.log("Socket closed or failed!");
    };
    
   ws.onmessage = function(message) {
       if(message == "") {
       		wsPoke = true;
       };
       return $wsPoke;
    };

   ws.onerror = function(error) {
      console.log('Error detected: ' + error);
   };

   return wsPoke;
});