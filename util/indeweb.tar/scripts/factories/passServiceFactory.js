angular.module('indeApp.factories').factory('passService', function () {
  return {
      sharedVariable: { filt: '' }
   };
});