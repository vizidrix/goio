angular.module('indeApp.factories').factory('passService', function () {
  return {
      sharedVariable: { filt: '' },
      LoginVisible: {lv:''},
      Logedin: {li:''}
   };
});