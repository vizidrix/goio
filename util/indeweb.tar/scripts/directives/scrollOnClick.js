angular.module("scrollOnClick", [])
.directive('scrollOnClick', function() {
  return {
    restrict: 'A',
    link: function(scope, $elm) {
      $elm.on('click', function() {
         setTimeout(function () {   
            var winH = window.innerHeight
            var oSet = (winH / 2) - 180
            $("body").animate({scrollTop: $elm.offset().top - oSet}, "slow");
         }, 301)
      });
    }
  }
});