angular.module("tooltip", [])
.directive('tooltip', function ($compile) {
        return {
            restrict: 'A',
            scope: true,
            link: function (scope, element, attrs, ctrl) {

               scope.text = attrs.tooltip;
               var tooltE = $compile('<div class="tooltip"><div class="ttCont">{{text}}</div></div>')(scope);

               window.element = element;
               window.tooltE = tooltE;

               element.parent().append(tooltE);
               element.bind('mouseover', function () {
                  tooltE.addClass('active');
               });

               element.bind('mouseout', function () {
                  tooltE.removeClass('active');
               });
               element.bind('mousedown', function () {
                  tooltE.removeClass('active');
               });

            }
         }
      });