angular.module("tooltip", [])
.directive('tooltip', function ($document, $compile) {
        return {
            restrict: 'A',
            scope: true,
            link: function (scope, element, attrs, ctrl) {

               scope.text = attrs.tooltip;
               var tooltE = $compile('<div class="tooltip"><div class="ttCont">{{text}}</div></div>')(scope);

               var offset = element.offset();

               offset.top = offset.top + 30;

               window.element = element;
               window.tooltE = tooltE;

               tooltE.offset(offset);

               element.parent().append(tooltE);
               element.bind('mouseover', function () {
                  tooltE.addClass('active');
               });

               element.bind('mouseout', function () {
                  tooltE.removeClass('active');
               });

            }
         }
      });