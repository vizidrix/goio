angular.module("dropdown", [])
.directive('dropdown', function ($document, $compile) {
        return {
            restrict: 'A',
            scope: true,
            link: function (scope, element, attrs, ctrl) {

               scope.txt = attrs.dropdown;
               switch (scope.txt) {
                  case 'filters': var dropdE = $compile('<div class="dropdown"><div class="ddCont"><div class="usrMnu" ng-repeat="dd in filterMnu"><a ng-click="inputVar.filt=dd.linkID">{{dd.linkTxt}}</a></div></div></div>')(scope);
                                  break;
                  case 'usrMnu': var dropdE = $compile('<div class="dropdown"><div class="ddCont"><div class="usrMnu" ng-repeat="dd in usrMnu"><a>{{dd.linkTxt}}</a></div></div></div>')(scope);
                                 break;

               }
               //var dropdE = $compile('<div class="dropdown"><div class="ddCont"><div class="usrMnu" ng-repeat="dd in filterMnu"><a ng-click="inputVar.filt=dd.linkID">{{dd.linkTxt}}</a></div></div></div>')(scope);
               //var dropdE = $compile('<div class="dropdown"><div class="ddCont"><div class="usrMnu" ng-repeat="dd in usrMnu"><a>{{dd.linkTxt}}</a></div></div></div>')(scope);
               //var offset = element.position();  
               
               //offset.top = offset.top + 36;
               //offset.left = offset.left - 3;
               window.element = element;
               window.dropdE = dropdE;

               //$document.find('body').append(dropdE);
               element.parent().append(dropdE);
               var isOpen = false;
               var shouldClose = false;
               var setCloser = function() {
                  setTimeout(function() {
                     if(shouldClose) {
                        dropdE.removeClass('clicked');
                        element.parent().removeClass('navIconsO');
                        isOpen = false;
                     }
                  },240);
               }
               element.bind('mousedown', function(event) {
                  if(isOpen) {
                     dropdE.removeClass('clicked');
                     element.parent().removeClass('navIconsO');
                     isOpen = false;
                  } else {
                     //alert('move to: [' + element.position().top + ',' + element.position().left + ']');
                     //var offset = element.position();
                     //offset.top = offset.top + 36;
                     //offset.left = offset.left - 5;
                     //dropdE.offset(offset);
                     //dropdE.offset(offset);
                     //dropdE.offset(offset);
                     //offset.top = element.position().top + 36;
                     //offset.left = element.position().left - 3;
                     dropdE.addClass('clicked');
                     element.parent().addClass('navIconsO');
                     shouldClose = false;
                     isOpen = true;
                  }
               });
               element.bind('mouseenter', function(event) {
                  shouldClose = false;
               });
               element.bind('mouseleave', function(event) {
                  shouldClose = true;
                  setCloser();
               });
               dropdE.bind('mouseenter', function(event) {
                  shouldClose = false;
               });
               dropdE.bind('mouseleave', function(event) {
                  shouldClose = true;
                  setCloser();
               });

            }
         }
      });