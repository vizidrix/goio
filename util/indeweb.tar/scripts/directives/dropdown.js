angular.module("dropdown", [])
.directive('dropdown', function ($document, $compile) {
        return {
            restrict: 'A',
            scope: false,
            link: function (scope, element, attrs, ctrl) {

               scope.txt = attrs.dropdown;
               switch (scope.txt) {
                  case 'filters': var dropdE = $compile('<div class="dropdown"><div class="ddCont"><div class="fltMnu" ng-repeat="dd in filterMnu"><a ng-click="inputVar.filt=dd.linkID" class="filtTxt">{{dd.linkTxt}}</a></div></div></div>')(scope);
                                  break;
                  case 'usrMnu': var dropdE = $compile('<div class="dropdown"><div class="ddCont"><div class="usrMnu" ng-repeat="dd in usrMnu"><a ng-click="syslink(dd.clickAction);">{{dd.linkTxt}}</a></div><div class="usrMnu" ng-hide="Logedin" ng-click="$scope.LoginFromMenu = true; requestLogin();">Login</div><div class="usrMnu" style="cursor: pointer;" ng-show="Logedin" ng-click="logOut();" >Logout</div></div></div>')(scope);
                                 break;
                  case 'notif':  var dropdE = $compile('<div class="dropdown"><div class="ddCont"><div class="canButton" ng-click="clearAllNotifications();" ng-show="ntfcLen">Clear All Notifications</div><div class="noNtfc" ng-click="clearAllNotifications();" ng-hide="ntfcLen">No Notifications</div><div class="notMnu" ng-repeat="dd in notificationData" ng-switch on="dd.Type"><hr><div ng-switch-when="error" class="fontAwe error">&#xf071;</div><div ng-switch-when="added" class="fontAwe added">&#xf06b;</div><div ng-switch-when="installed" class="fontAwe installed">&#xf0e7;</div><div ng-switch-when="updateinstalled" class="fontAwe updateinstalled">&#xf0e7;</div><div ng-switch-when="updateable" class="fontAwe updateable">&#xf01b;</div><div ng-switch-when="downloaded" class="fontAwe downloaded">&#xf0ed;</div><div ng-switch-when="updatedownloaded" class="fontAwe updatedownloaded">&#xf0ed;</div><div class="ntfcTxt">{{dd.Title}}</div><div ng-click="clearNotification(dd.CmdClear)" class="csnButton"><a class="fontAwe">&#xf056;</a> Clear</div></div><hr></div></div>')(scope); 
                                 break;
               }
    
               window.element = element;
               window.dropdE = dropdE;

               element.parent().append(dropdE);
               var isOpen = false;
               var shouldClose = false;
               var setCloser = function() {
                  setTimeout(function() {
                     if(shouldClose) {
                        dropdE.removeClass('clicked');
                        element.parent().removeClass('navIconsO');
                        isOpen = false;
                     }
                  },240);
               }
               element.bind('mousedown', function(event) {
                  if(isOpen) {
                     dropdE.removeClass('clicked');
                     element.parent().removeClass('navIconsO');
                     isOpen = false;
                  } else {
                     dropdE.addClass('clicked');
                     element.parent().addClass('navIconsO');
                     shouldClose = false;
                     isOpen = true;
                  }
               });
               element.bind('mouseenter', function(event) {
                  shouldClose = false;
               });
               element.bind('mouseleave', function(event) {
                  shouldClose = true;
                  setCloser();
               });
               dropdE.bind('mouseenter', function(event) {
                  shouldClose = false;
               });
               dropdE.bind('mouseleave', function(event) {
                  shouldClose = true;
                  setCloser();
               });

            }
         }
      });