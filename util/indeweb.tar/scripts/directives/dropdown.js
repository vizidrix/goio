angular.module("dropdown", [])
.directive('dropdown', function ($document, $compile) {
        return {
            restrict: 'A',
            scope: true,
            link: function (scope, element, attrs, ctrl) {

               scope.text = attrs.dropdown;
               var dropdE = $compile('<div class="dropdown"><div class="ddCont">{{text}}</div></div>')(scope);

               var offset = element.offset();

               offset.top = offset.top + 30;

               window.element = element;
               window.dropdE = dropdE;

               dropdE.offset(offset);

               element.parent().append(dropdE);
               element.bind('click', function () {
                  dropdE.addClass('active');
               });

               element.bind('click', function () {
                  dropdE.removeClass('active');
               });

            }
         }
      });