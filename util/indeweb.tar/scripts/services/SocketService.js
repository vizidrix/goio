angular.module('indeApp.services').service('socketService', function () {
  /*var ws = new WebSocket("ws://127.0.0.1:8010/ws");
   ws.onopen = function() {

      ws.send(JSON.stringify({'index':10,'key':'angular_value','value':'moar stuff'}));
   };
   ws.onmessage = function(message) {
      //alert(message);
      var wsData = JSON.parse(message.data);
      //alert('wsData: ' + wsData.Index + ' k:' + wsData.Key + ' v:' + wsData.Value);
   };
   ws.onclose = function() {
      //alert('closed ws');
   };*/
});