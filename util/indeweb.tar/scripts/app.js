angular.module('indeApp', [
  'scrollOnClick',
  'dropdown',
  'tooltip',
  'indeApp.controllers',
  'indeApp.factories',
  'indeApp.services'
]);
