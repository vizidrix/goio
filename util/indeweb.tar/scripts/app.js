angular.module('indeApp', [
  'scrollOnClick',
  'tooltip',
  'dropdown',
  'indeApp.controllers',
  'indeApp.factories',
  'indeApp.services'
]);
